function navToHome() {
    // document.getElementById("myEvent").style.borderColor = "white";
    window.location.href = "index.html";
}